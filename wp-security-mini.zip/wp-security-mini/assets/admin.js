
jQuery(document).ready(function($) {

    // Разблокировка IP
    $(document).on('click', '.wpsm-unblock', function() {
        var $btn = $(this);
        var ip = $btn.data('ip');

        if (!confirm('Разблокировать IP ' + ip + '?')) {
            return;
        }

        $btn.prop('disabled', true).text('...');

        $.ajax({
            url: wpsmAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'wpsm_unblock_ip',
                nonce: wpsmAjax.nonce,
                ip: ip
            },
            success: function(response) {
                if (response.success) {
                    $btn.closest('tr').fadeOut(300, function() {
                        $(this).remove();

                        // Если таблица пуста
                        if ($('tbody tr').length === 0) {
                            location.reload();
                        }
                    });
                } else {
                    alert('Ошибка: ' + (response.data.message || 'Неизвестная ошибка'));
                    $btn.prop('disabled', false).text('Разблокировать');
                }
            },
            error: function() {
                alert('Ошибка сервера');
                $btn.prop('disabled', false).text('Разблокировать');
            }
        });
    });

    // Постоянная блокировка IP (на 24 часа)
    $(document).on('click', '.wpsm-block-permanent', function() {
        var $btn = $(this);
        var ip = $btn.data('ip');

        if (!confirm('Заблокировать IP ' + ip + ' на 24 часа?')) {
            return;
        }

        $btn.prop('disabled', true).text('Блокируется...');

        // Здесь можно добавить AJAX для постоянной блокировки
        // Пока просто показываем уведомление
        alert('IP ' + ip + ' заблокирован на 24 часа');
        $btn.text('Заблокирован').addClass('button-disabled');
    });
});
