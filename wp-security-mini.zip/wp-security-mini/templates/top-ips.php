<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap wpsm-top-ips">
    <h1>🎯 Топ-10 самых активных атакующих IP</h1>

    <div class="wpsm-section">
        <p style="color:#666;margin-bottom:20px;">
            Данные за последние 7 дней. Показаны IP адреса с наибольшим количеством подозрительной активности.
        </p>

        <?php if (!empty($top_ips)): ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th width="60">#</th>
                    <th>IP адрес</th>
                    <th>Типы событий</th>
                    <th>Количество атак</th>
                    <th>Последняя активность</th>
                    <th>Действие</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $rank = 1;
                foreach ($top_ips as $ip): 
                ?>
                <tr>
                    <td><strong><?php echo $rank++; ?></strong></td>
                    <td><code><?php echo esc_html($ip->ip_address); ?></code></td>
                    <td><?php echo esc_html($ip->events); ?></td>
                    <td>
                        <strong style="color:#dc3545;font-size:16px;">
                            <?php echo number_format($ip->attack_count); ?>
                        </strong>
                    </td>
                    <td><?php echo date('d.m.Y H:i', strtotime($ip->last_seen)); ?></td>
                    <td>
                        <button class="button wpsm-block-permanent" data-ip="<?php echo esc_attr($ip->ip_address); ?>">
                            Заблокировать на 24ч
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div style="text-align:center;padding:50px;">
            <p style="font-size:48px;">✅</p>
            <h3>Атак не обнаружено</h3>
            <p style="color:#666;">За последние 7 дней подозрительной активности не было</p>
        </div>
        <?php endif; ?>
    </div>

    <div class="wpsm-info-box">
        <h3>📖 Типы событий</h3>
        <ul>
            <li><strong>ddos_attack:</strong> DDoS атака (более 100 запросов за 10 секунд)</li>
            <li><strong>malicious:</strong> Вредоносный запрос (SQL injection, XSS)</li>
            <li><strong>failed_login:</strong> Неудачная попытка входа</li>
            <li><strong>blocked_access:</strong> Попытка доступа с заблокированного IP</li>
        </ul>
    </div>
</div>
